# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(lp_dualsimplex src/lp_dualsimplex.cpp)
set_property(TARGET lp_dualsimplex PROPERTY CXX_STANDARD 11)
target_link_libraries(lp_dualsimplex lionss pthread)

add_executable(TmuxPane src/TmuxPane.cpp)
set_property(TARGET TmuxPane PROPERTY CXX_STANDARD 11)
target_link_libraries(TmuxPane lionss pthread)

add_executable(fzf-preview src/fzf-preview.cpp)
set_property(TARGET fzf-preview PROPERTY CXX_STANDARD 11)
target_link_libraries(fzf-preview lionss pthread)

add_executable(gcTier src/gcTier.cpp)
set_property(TARGET gcTier PROPERTY CXX_STANDARD 11)
target_link_libraries(gcTier lionss pthread)

add_executable(selinux-relabel src/selinux-relabel.cpp)
set_property(TARGET selinux-relabel PROPERTY CXX_STANDARD 11)
target_link_libraries(selinux-relabel lionss pthread)

add_executable(ParquetRollup src/ParquetRollup.cpp)
set_property(TARGET ParquetRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(ParquetRollup lionss pthread)

add_executable(lodestar src/lodestar.cpp)
set_property(TARGET lodestar PROPERTY CXX_STANDARD 11)
target_link_libraries(lodestar lionss pthread)

add_executable(ssrHydrate src/ssrHydrate.cpp)
set_property(TARGET ssrHydrate PROPERTY CXX_STANDARD 11)
target_link_libraries(ssrHydrate lionss pthread)

add_executable(TcpCubic src/TcpCubic.cpp)
set_property(TARGET TcpCubic PROPERTY CXX_STANDARD 11)
target_link_libraries(TcpCubic lionss pthread)

add_executable(biquad-lp src/biquad-lp.cpp)
set_property(TARGET biquad-lp PROPERTY CXX_STANDARD 11)
target_link_libraries(biquad-lp lionss pthread)

add_executable(zerolog src/zerolog.cpp)
set_property(TARGET zerolog PROPERTY CXX_STANDARD 11)
target_link_libraries(zerolog lionss pthread)

add_executable(kmer-count31 src/kmer-count31.cpp)
set_property(TARGET kmer-count31 PROPERTY CXX_STANDARD 11)
target_link_libraries(kmer-count31 lionss pthread)

add_executable(exposureFuse src/exposureFuse.cpp)
set_property(TARGET exposureFuse PROPERTY CXX_STANDARD 11)
target_link_libraries(exposureFuse lionss pthread)

add_executable(mux9 src/mux9.cpp)
set_property(TARGET mux9 PROPERTY CXX_STANDARD 11)
target_link_libraries(mux9 lionss pthread)

add_executable(tailwind-purge src/tailwind-purge.cpp)
set_property(TARGET tailwind-purge PROPERTY CXX_STANDARD 11)
target_link_libraries(tailwind-purge lionss pthread)

add_executable(deltaV_budget src/deltaV_budget.cpp)
set_property(TARGET deltaV_budget PROPERTY CXX_STANDARD 11)
target_link_libraries(deltaV_budget lionss pthread)

add_executable(flaxen src/flaxen.cpp)
set_property(TARGET flaxen PROPERTY CXX_STANDARD 11)
target_link_libraries(flaxen lionss pthread)

add_executable(serdetangent src/serdetangent.cpp)
set_property(TARGET serdetangent PROPERTY CXX_STANDARD 11)
target_link_libraries(serdetangent lionss pthread)

add_executable(bbr-probe src/bbr-probe.cpp)
set_property(TARGET bbr-probe PROPERTY CXX_STANDARD 11)
target_link_libraries(bbr-probe lionss pthread)

add_executable(behaviorTree src/behaviorTree.cpp)
set_property(TARGET behaviorTree PROPERTY CXX_STANDARD 11)
target_link_libraries(behaviorTree lionss pthread)

add_executable(ReverbTail src/ReverbTail.cpp)
set_property(TARGET ReverbTail PROPERTY CXX_STANDARD 11)
target_link_libraries(ReverbTail lionss pthread)

add_executable(WaveletDenoise src/WaveletDenoise.cpp)
set_property(TARGET WaveletDenoise PROPERTY CXX_STANDARD 11)
target_link_libraries(WaveletDenoise lionss pthread)

add_executable(prefetch_stride src/prefetch_stride.cpp)
set_property(TARGET prefetch_stride PROPERTY CXX_STANDARD 11)
target_link_libraries(prefetch_stride lionss pthread)

add_executable(dedupeBlock src/dedupeBlock.cpp)
set_property(TARGET dedupeBlock PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupeBlock lionss pthread)

add_executable(orbit-propagate src/orbit-propagate.cpp)
set_property(TARGET orbit-propagate PROPERTY CXX_STANDARD 11)
target_link_libraries(orbit-propagate lionss pthread)

add_executable(reactionWheel src/reactionWheel.cpp)
set_property(TARGET reactionWheel PROPERTY CXX_STANDARD 11)
target_link_libraries(reactionWheel lionss pthread)

add_executable(sift-match src/sift-match.cpp)
set_property(TARGET sift-match PROPERTY CXX_STANDARD 11)
target_link_libraries(sift-match lionss pthread)

add_executable(rocksdbCompact src/rocksdbCompact.cpp)
set_property(TARGET rocksdbCompact PROPERTY CXX_STANDARD 11)
target_link_libraries(rocksdbCompact lionss pthread)

add_executable(PidAutotune src/PidAutotune.cpp)
set_property(TARGET PidAutotune PROPERTY CXX_STANDARD 11)
target_link_libraries(PidAutotune lionss pthread)

add_executable(nvmeTrim src/nvmeTrim.cpp)
set_property(TARGET nvmeTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(nvmeTrim lionss pthread)

