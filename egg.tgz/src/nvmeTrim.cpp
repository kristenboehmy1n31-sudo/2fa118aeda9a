// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Trim unused blocks"); }
int main(){
  announce();
  return lionss_run_workload("nvmeTrim");
}
