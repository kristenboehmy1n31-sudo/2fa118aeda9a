// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Probe bottleneck bandwidth\n", stdout);
  return lionss_run_workload("bbr-probe");
}
