// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Design lowpass biquad\n", stdout);
  return lionss_run_workload("biquad-lp");
}
