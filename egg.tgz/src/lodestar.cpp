// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Fix on lodestar\n", stdout);
  return lionss_run_workload("lodestar");
}
