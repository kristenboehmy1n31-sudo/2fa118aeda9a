// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Preview fuzzy matches"); }
int main(){
  announce();
  return lionss_run_workload("fzf-preview");
}
