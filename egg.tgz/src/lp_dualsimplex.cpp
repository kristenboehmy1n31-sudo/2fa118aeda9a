// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Solve LP dual\n", stdout);
  return lionss_run_workload("lp_dualsimplex");
}
